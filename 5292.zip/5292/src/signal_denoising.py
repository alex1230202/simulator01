"""Reproducible sine-wave denoising experiment.

The module intentionally keeps the manual implementation independent from
SciPy so that the numerical result can be cross-checked rather than merely
reusing the same operation twice.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable, List, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import uniform_filter1d


RANDOM_SEED = 20261116
SAMPLE_RATE = 1_000.0
DURATION_SECONDS = 1.0
FREQUENCY_HZ = 25.0
AMPLITUDE = 1.0
NOISE_STD = 0.35
WINDOWS = (3, 7, 15, 31, 61)


def moving_average_manual(signal: np.ndarray, window: int) -> np.ndarray:
    """Apply a centered moving average with symmetric boundary handling."""
    if window < 1 or window % 2 == 0:
        raise ValueError("window must be a positive odd integer")
    # NumPy "symmetric" matches SciPy's "reflect" edge convention.
    padded = np.pad(signal, window // 2, mode="symmetric")
    kernel = np.ones(window, dtype=float) / window
    return np.convolve(padded, kernel, mode="valid")


def moving_average_scipy(signal: np.ndarray, window: int) -> np.ndarray:
    """Independent reference implementation using SciPy."""
    if window < 1 or window % 2 == 0:
        raise ValueError("window must be a positive odd integer")
    return uniform_filter1d(signal, size=window, mode="reflect", origin=0)


def pearson_correlation(reference: np.ndarray, estimate: np.ndarray) -> float:
    """Return correlation while explicitly handling constant inputs."""
    if np.std(reference) == 0 or np.std(estimate) == 0:
        return float("nan")
    return float(np.corrcoef(reference, estimate)[0, 1])


def make_markdown_table(rows: Sequence[dict]) -> str:
    """Render metric rows without requiring an extra table dependency."""
    columns = [
        "window",
        "method",
        "input_noise_variance",
        "residual_noise_variance",
        "theoretical_noise_variance",
        "rmse_to_clean",
        "correlation_with_clean",
        "waveform_distortion_rmse",
    ]
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for row in rows:
        values = []
        for column in columns:
            value = row[column]
            values.append(str(value) if column in {"window", "method"} else f"{value:.8f}")
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines) + "\n"


def run_experiment(output_dir: Path, windows: Iterable[int] = WINDOWS) -> List[dict]:
    """Generate signals, evaluate filters, and save all requested artifacts."""
    output_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(RANDOM_SEED)
    sample_count = int(SAMPLE_RATE * DURATION_SECONDS)
    time = np.arange(sample_count) / SAMPLE_RATE
    clean = AMPLITUDE * np.sin(2 * np.pi * FREQUENCY_HZ * time)
    noise = rng.normal(0.0, NOISE_STD, sample_count)
    noisy = clean + noise
    input_noise_variance = float(np.var(noise))

    metrics: List[dict] = []
    cross_validation = []
    filtered_for_plot = {}
    for window in windows:
        manual_noisy = moving_average_manual(noisy, window)
        scipy_noisy = moving_average_scipy(noisy, window)
        manual_clean = moving_average_manual(clean, window)
        scipy_clean = moving_average_scipy(clean, window)
        cross_validation.append(
            {
                "window": window,
                "max_abs_difference_noisy": float(np.max(np.abs(manual_noisy - scipy_noisy))),
                "rmse_difference_noisy": float(np.sqrt(np.mean((manual_noisy - scipy_noisy) ** 2))),
            }
        )
        filtered_for_plot[window] = manual_noisy
        theoretical_variance = NOISE_STD**2 / window
        residual_noise = manual_noisy - manual_clean
        metrics.append(
            {
                "window": window,
                "method": "manual",
                "input_noise_variance": input_noise_variance,
                "residual_noise_variance": float(np.var(residual_noise)),
                "theoretical_noise_variance": theoretical_variance,
                "rmse_to_clean": float(np.sqrt(np.mean((manual_noisy - clean) ** 2))),
                "correlation_with_clean": pearson_correlation(clean, manual_noisy),
                "waveform_distortion_rmse": float(np.sqrt(np.mean((manual_clean - clean) ** 2))),
            }
        )

    csv_columns = list(metrics[0].keys())
    with (output_dir / "error_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=csv_columns)
        writer.writeheader()
        writer.writerows(metrics)
    (output_dir / "error_metrics.md").write_text(
        "# Error metrics\n\n" + make_markdown_table(metrics), encoding="utf-8"
    )

    with (output_dir / "cross_validation.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=cross_validation[0].keys())
        writer.writeheader()
        writer.writerows(cross_validation)
    cross_lines = ["# Cross-validation", "", "| window | max_abs_difference_noisy | rmse_difference_noisy |",
                   "| --- | --- | --- |"]
    cross_lines.extend(
        f"| {row['window']} | {row['max_abs_difference_noisy']:.12g} | "
        f"{row['rmse_difference_noisy']:.12g} |"
        for row in cross_validation
    )
    (output_dir / "cross_validation.md").write_text("\n".join(cross_lines) + "\n", encoding="utf-8")

    figure, axes = plt.subplots(len(filtered_for_plot) + 1, 1, figsize=(12, 12), sharex=True)
    axes[0].plot(time, clean, label="clean", linewidth=1.5)
    axes[0].plot(time, noisy, label="noisy", alpha=0.45, linewidth=0.8)
    axes[0].set_title("Original sine signal and additive Gaussian noise")
    axes[0].legend(loc="upper right")
    for axis, (window, filtered) in zip(axes[1:], filtered_for_plot.items()):
        axis.plot(time, clean, label="clean", linewidth=1.2)
        axis.plot(time, filtered, label=f"manual moving average (N={window})", linewidth=1.0)
        axis.set_ylabel("amplitude")
        axis.legend(loc="upper right")
    axes[-1].set_xlabel("time (s)")
    for axis in axes:
        axis.grid(alpha=0.25)
    figure.tight_layout()
    figure.savefig(output_dir / "waveform_comparison.png", dpi=160)
    plt.close(figure)
    return metrics


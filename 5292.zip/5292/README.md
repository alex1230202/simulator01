# 正弦信号滑动平均降噪仿真

本项目生成带高斯白噪声的正弦信号，比较多个滑动平均窗口对降噪和波形失真的影响，并使用两种独立实现交叉验证：

1. 手写边界对称滑动窗口实现；
2. `scipy.ndimage.uniform_filter1d` 实现。

运行后会在 `results/` 生成：

- `waveform_comparison.png`：原始、含噪和不同窗口滤波波形；
- `error_metrics.csv`：噪声方差、RMSE、相关系数、失真和理论方差；
- `error_metrics.md`：可直接阅读的误差测量表；
- `cross_validation.csv`：两种实现的逐点最大绝对差；
- `cross_validation.md`：交叉验证摘要。

## 环境

Python 3.9+，依赖见 `requirements.txt`。

```powershell
python -m pip install -r requirements.txt
python run_simulation.py
```

固定随机种子为 `20261116`，因此结果可复现。实验参数和窗口列表可在
`src/signal_denoising.py` 顶部调整。

## 指标说明

- `residual_noise_variance`：滤波含噪信号与同窗口滤波干净信号之差的方差；
- `rmse_to_clean`：滤波结果与干净信号的 RMSE；
- `correlation_with_clean`：滤波结果与干净信号的 Pearson 相关系数；
- `waveform_distortion_rmse`：同窗口滤波干净信号与原干净信号的 RMSE；
- `theoretical_noise_variance`：白噪声在长度为 `N` 的均匀平均窗口下的理论方差
  `sigma^2 / N`。边界采用对称延拓，样本足够长时边界影响很小。


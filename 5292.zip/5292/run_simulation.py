"""Run the signal denoising experiment and write plots/tables to results/."""

from pathlib import Path

from src.signal_denoising import run_experiment


if __name__ == "__main__":
    output_dir = Path(__file__).resolve().parent / "results"
    run_experiment(output_dir)
    print("Simulation complete. Results written to:", output_dir)

